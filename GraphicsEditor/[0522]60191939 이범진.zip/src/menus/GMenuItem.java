package menus;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JMenuItem;

public class GMenuItem extends JMenuItem {

	public GMenuItem() {
		// TODO Auto-generated constructor stub
	}

	public GMenuItem(Icon icon) {
		super(icon);
		// TODO Auto-generated constructor stub
	}

	public GMenuItem(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

	public GMenuItem(Action a) {
		super(a);
		// TODO Auto-generated constructor stub
	}

	public GMenuItem(String text, Icon icon) {
		super(text, icon);
		// TODO Auto-generated constructor stub
	}

	public GMenuItem(String text, int mnemonic) {
		super(text, mnemonic);
		// TODO Auto-generated constructor stub
	}

}
