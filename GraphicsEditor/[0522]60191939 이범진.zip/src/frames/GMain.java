package frames;
import javax.swing.JFrame;

public class GMain {

	public GMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		GMainFrame mainFrame = new GMainFrame();
		mainFrame.setVisible(true);
		mainFrame.initialize();

	}

}
